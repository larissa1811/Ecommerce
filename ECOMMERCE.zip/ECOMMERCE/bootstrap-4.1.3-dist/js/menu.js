$(document).ready(function(){
    //Selecionar todos os botões e monitorar os cliques
    $('.btn').click(function(e){
        e.preventDefault()
        //Capturar o ID do botão clicado
        var ID = $(this).attr('id')
        switch (ID) {
            case 'chocolate':
            $('img').attr('src', 'img/Bolo-de-chocolate.jpg')
            break
            case 'coconut':
            $('img').attr('src', 'img/Bolo-coco.png')
            break
            case 'brownie':
            $('img').attr('src', 'img/brownie.png')
            break
            case 'brigadeiro':
            $('img').attr('src', 'img/Brigadeiro.jpg')
            break
            case 'beijinho':
            $('img').attr('src', 'img/Beijinho.jpg')
            break
            case 'donuts':
            $('img').attr('src', 'img/donuts-de-morango.jpg')
            break
            default:console.log('Produto não existe')
        }
    })
})
